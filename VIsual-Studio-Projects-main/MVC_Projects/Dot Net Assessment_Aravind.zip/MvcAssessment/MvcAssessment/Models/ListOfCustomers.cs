﻿namespace MvcAssessment.Models
{
    public class ListOfCustomers
    {
    }
}
