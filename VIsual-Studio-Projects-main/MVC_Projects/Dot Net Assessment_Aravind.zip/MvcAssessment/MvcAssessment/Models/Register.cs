﻿namespace MvcAssessment.Models
{
    public class Register
    {
    }
}
